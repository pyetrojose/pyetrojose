function setup() {
  createCanvas(900, 900);
}

function draw() {
  background(220);
}function setup() {
  createCanvas(900, 900);
}

function draw() {
  background(220);
}function setup() {
  createCanvas(900, 900);
}

function draw() {
  background("white");
}function setup() {
  createCanvas(900, 900);
}

function draw() {
  background("white");
    rect(0, 0, 100, 150)
}function setup() {
  createCanvas(900, 900);
}

function draw() {
  background("white");

    stroke("red")
    fill("green")
    rect(0, 0, 100, 150)
}function setup() {
  createCanvas(900, 900);
}

function draw() {
  background("#0026FC");

  stroke("#00FFE7")
  fill("green")
  rect(100, 250, 100, 150)
}function setup() {
  createCanvas(900, 900);
}

function draw() {
  background("#5C00FF");

  stroke("#08E3FF")
  fill("green")
  rect(mouseX, mouseY, 40, 40)
}function setup() {
  createCanvas(900, 900);
  background("#5500EC")
}

function draw() {
  stroke("#00E2FF");
  fill("#00FD0A");
  
  
  if (mouseIsPressed) {
    rect(mouseX, mouseY, 20, 35);
  }function setup() {
  createCanvas(400, 400);
  background(color(100, 0 , 0));
  cor = color(random(0, 255), random(0, 255), random(0, 255));
  posicaoHorizontal = 200;
  posicaoVertical = 200;
}if(mouseIsPressed){
    cor = color(random(0, 255), random(0, 255), random(0, 255));
}let cor;
let posicaoHorizontal; // x
let posicaoVertical; //x
}

function draw() {
  stroke("#00BCD4");
  fill("#00F00A");
  
  
  if (mouseIsPressed) {
    rect(mouseX, mouseY, 20, 35);
  }fun
criarCanvas(900,900);
  background("white");
}

function draw() {
}function setup() {
  createCanvas (900,900);
  background("white")
}

function draw() {
  stroke("blue");
  fill("red");
  
  
  if (mouseIsPressed) {
    rect(mouseX, mouseY, 20, 35);
  }
}




















